#include <ESP8266WiFi.h>



#include <time.h>  // time() ctime()

time_t now;  // this is the epoch
tm myTimeInfo;
int Year;
int Month;
int Day;
int Hour;
int Minute;
int Second;
int DayIndex;

void updateMyTimeVars() {
  Year = myTimeInfo.tm_year + 1900;  // years since 1900
  Month = myTimeInfo.tm_mon + 1;     // January = 0 (!)
  Day = myTimeInfo.tm_mday;
  Hour = myTimeInfo.tm_hour;
  Minute = myTimeInfo.tm_min;
  Second = myTimeInfo.tm_sec;
  DayIndex = myTimeInfo.tm_wday;
}


#include <WiFiManager.h>

WiFiManager wifiManager;
#include <Preferences.h>


#include "SSD1306Wire.h"  // legacy: #include "SSD1306.h"
#include "fonts.h"


Preferences preferences;
#define BUTTON_PIN 14
#define AP_SSID "ESP-Clock-AP"
const uint16_t NTPwait = 10; //how many seconds to wait before giving up on NTP Server

char dayOfWeek[7][10] = {"Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"};

char timeZone[50];
int8_t hr = 0;  //24hr time variable
int8_t dateshow = 0;  //show date variable
int8_t hourTime = 0;
int8_t minuteTime = 0;
String hourZero = "";
String minuteZero = "";

char ntp1[15];
char ntp2[15];
char ntp3[15];

// Initialize the OLED display using Arduino Wire:
SSD1306Wire display(0x3c, 4, 5);  // ADDRESS, SDA, SCL  -  SDA and SCL usually populate automatically based on your board's pins_arduino.h e.g. https://github.com/esp8266/Arduino/blob/master/variants/nodemcu/pins_arduino.h

#include <TzDbLookup.h>

void timeSynced() {
  Serial.println("THE TIME SYNCED!!!!!!! (SHOULD BE ONCE EVEY HOUR)");
};
void (*resetFunc)(void) = 0;  //declare reset function @ address 0

void displayWifiText () {
  display.setFont(Roboto_Bold_26);
  display.setTextAlignment(TEXT_ALIGN_CENTER);
  display.clear();
  display.drawString(64, 4, "Wi-Fi");
  display.display();
};

void configMode (boolean buttonon) {
  Serial.println("Entered config mode");
  Serial.println(WiFi.softAPIP());
  Serial.println(AP_SSID);
  display.clear();
  display.setFont(Roboto_17);
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  if (buttonon) {
    display.drawString(1, 1, "Config Button");
  } else {
    display.drawString(1, 1, "Config Mode");
  }
  display.setFont(Roboto_12);
  display.drawString(1,24, "SSID: " + String(AP_SSID));
  display.drawString(1,44, "IP: 192.168.4.1");
  display.display();
};

std::function<void(WiFiManager*)> configCallback = [](WiFiManager* myWiFiManager) {
    configMode(false);
};
void setup() {

  Serial.begin(115200);
  pinMode(2, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  display.init();
  display.flipScreenVertically();


  preferences.begin("my-app", false);
  short brightness = preferences.getShort("brightness", 50);

  display.setContrast(brightness,  int(brightness*2.41),  int(brightness*.64));
 
  displayWifiText();

  preferences.getString("timeZone", "Etc/Universal").toCharArray(timeZone, 50);
  hr = preferences.getChar("hr", 1);
  dateshow = preferences.getChar("dateshow", 1);
  preferences.getString("ntp1", "192.168.0.1").toCharArray(ntp1, 15);     // default NIST time server 1
  preferences.getString("ntp2", "132.163.97.1").toCharArray(ntp2, 15);    // default NIST time server 2
  preferences.getString("ntp3", "128.138.140.44").toCharArray(ntp3, 15);  // default NIST time server 3
  char brightstr[5];
  char dateshowstr[3];
  char hrstr[3];


  itoa(brightness, brightstr, 10);
  itoa(hr, hrstr, 10);
  itoa(dateshow, dateshowstr, 10);


  //delay(650);
  wifiManager.setConnectTimeout(60); // 1 minute of wifi before moving to AP
  wifiManager.setConfigPortalTimeout(240);  // 4 minute timeout for AP
  WiFiManagerParameter timezone_custom("timezone_field", "timezone (POSIX TZ or IANA TZ format: Continent/City_Name)", timeZone, 50);
  WiFiManagerParameter brightness_custom("brightness_field", "brightness (0-100)", brightstr, 4);



  WiFiManagerParameter hr_custom("hr_field", "24hr Time (0 or 1)", hrstr, 1);
  WiFiManagerParameter dateshow_custom("hr_field", "Show date? (0 or 1)", dateshowstr, 1);
  WiFiManagerParameter ntp1_custom("ntp1_field", "NTP Server 1 (IP)", ntp1, 15);
  WiFiManagerParameter ntp2_custom("ntp2_field", "NTP Server 2 (IP)", ntp2, 15);
  WiFiManagerParameter ntp3_custom("ntp3_field", "NTP Server 3 (IP)", ntp3, 15);
  wifiManager.addParameter(&timezone_custom);
  wifiManager.addParameter(&brightness_custom);
wifiManager.addParameter(&dateshow_custom);
  wifiManager.addParameter(&hr_custom);
  wifiManager.addParameter(&ntp1_custom);
  wifiManager.addParameter(&ntp2_custom);
  wifiManager.addParameter(&ntp3_custom);
  wifiManager.setClass("invert");  // dark theme
  wifiManager.setAPCallback(configCallback);
  digitalWrite(2, LOW);
  if (digitalRead(BUTTON_PIN) == HIGH) {
    wifiManager.autoConnect(AP_SSID);
  } else {
    configMode(true);
    wifiManager.startConfigPortal(AP_SSID);
  };

  Serial.println("saving config:");

  String(ntp1_custom.getValue()).toCharArray(ntp1, 15);
  String(ntp2_custom.getValue()).toCharArray(ntp2, 15);
  String(ntp3_custom.getValue()).toCharArray(ntp3, 15);

  preferences.putString("ntp1", ntp1);
  preferences.putString("ntp2", ntp2);
  preferences.putString("ntp3", ntp3);
  Serial.println(ntp1);
  Serial.println(ntp2);
  Serial.println(ntp3);


  String(timezone_custom.getValue()).toCharArray(timeZone, 50);
  preferences.putString("timeZone", timeZone);
  brightness = String(brightness_custom.getValue()).toInt();


  hr = String(hr_custom.getValue()).toInt();
  dateshow = String(dateshow_custom.getValue()).toInt();
  preferences.putShort("brightness", brightness);
  display.setContrast(brightness,  int(brightness*2.41),  int(brightness*.64));



  preferences.putChar("hr", hr);
  preferences.putChar("dateshow", dateshow);
  preferences.end();
  Serial.println("\nConnected to the WiFi network");
  Serial.print("Local ESP32 IP: ");
  Serial.println(WiFi.localIP());
  uint8_t wifiattempts = 0;
  while ((WiFi.status() != WL_CONNECTED) and wifiattempts < 6) {
    wifiattempts = wifiattempts + 1;
    Serial.println("retrying wifi manager connection");
    displayWifiText();
    wifiManager.autoConnect(AP_SSID);
  };
  if (WiFi.status() != WL_CONNECTED) {
    resetFunc();
  };
  Serial.print("\nRSSI: ");
  Serial.print(WiFi.RSSI());
  WiFi.hostname(AP_SSID);


  Serial.print("\nThe brightness: ");
  Serial.print(brightness);
  Serial.println(" ");
  Serial.print("\nThe time zone: ");
  Serial.print(timeZone);
  Serial.println(" ");
  Serial.print("\nIs 24hr enabled?: ");
  Serial.print(hr);
  Serial.println(" ");
  Serial.print("\nIs showing date enabled?: ");
  Serial.print(dateshow);
  Serial.println(" ");






  settimeofday_cb(timeSynced);
  displayWifiText();
  display.setFont(Roboto_12);
  display.drawString(64, 44, "SSID: " + WiFi.SSID());
  display.display();
  delay(4000);
  displayWifiText();
  display.clear();
  display.drawString(64, 4, "NTP Sync");
  display.display();
  Serial.print("synchronising time");

  const char* timeZoneMain = TzDbLookup::getPosix(timeZone);

  if (timeZoneMain) {
    Serial.printf("\nPOSIX string for %s: %s\n", timeZone, timeZoneMain);
  } else {
    Serial.printf("\nPOSIX string for %s: not found\n", timeZone);
    timeZoneMain = timeZone;
  }
  configTime(timeZoneMain, ntp1);
  int counterNTP = 0;

  while (myTimeInfo.tm_year + 1900 < 2000 and counterNTP <= NTPwait*10) {
    time(&now);  // read the current time
    localtime_r(&now, &myTimeInfo);
    delay(100);
    Serial.print(".");
    counterNTP = counterNTP + 1;
  };
  if (myTimeInfo.tm_year + 1900 < 2000) {
    Serial.println("NTP1 Failed, trying NTP2");
    configTime(timeZoneMain, ntp2);
    counterNTP = 0;
    while (myTimeInfo.tm_year + 1900 < 2000 and counterNTP <= NTPwait*10) {
      time(&now);  // read the current time
      localtime_r(&now, &myTimeInfo);
      delay(100);
      Serial.print(".");
      counterNTP = counterNTP + 1;
    };
    if (myTimeInfo.tm_year + 1900 < 2000) {
      Serial.println("NTP2 Failed, trying NTP3");
      configTime(timeZoneMain, ntp3);
      counterNTP = 0;
      while (myTimeInfo.tm_year + 1900 < 2000 and counterNTP <= NTPwait*10) {
        time(&now);  // read the current time
        localtime_r(&now, &myTimeInfo);
        delay(100);
        Serial.print(".");
        counterNTP = counterNTP + 1;
      };
      if (myTimeInfo.tm_year + 1900 < 2000) {
      Serial.println("NTP3 Failed, ignoring");
  display.clear();
    display.drawString(64, 13, "NTP Failed!");
    display.display();
    delay(5000);
    resetFunc();
      } else {
        Serial.println("NTP3 Succeded");
      };
    } else {
      Serial.print("\n time synchronsized on ntp2 \n");
    };

  } else {
    Serial.print("\n time synchronsized on ntp1 \n");
  };



  yield(); // for the callback


  // variable above indicates that 4 resistors were placed on the digit pins.
  // set variable to 1 if you want to use 8 resistors on the segment pins.

  
  digitalWrite(2, HIGH);

  

};


// 'wifistrengthalertoutline', 15x15px
const unsigned char wifistrengthalertoutline [] PROGMEM = {
	0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0x1c, 0x3c, 0x06, 0x60, 0x06, 0x00, 0x0c, 0x20, 0x08, 0x28, 
	0x10, 0x24, 0x30, 0x26, 0x60, 0x03, 0xc0, 0x21, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'wifi-strength-1', 15x15px
const unsigned char wifistrength1 [] PROGMEM = {
	0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0x1c, 0x1c, 0x03, 0x60, 0x06, 0x30, 0x0c, 0x18, 0x08, 0x08, 
	0xd0, 0x05, 0xf0, 0x07, 0xe0, 0x03, 0xc0, 0x01, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'wifi-strength-3', 15x15px
const unsigned char wifistrength3 [] PROGMEM = {
	0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0x1c, 0x1c, 0x03, 0x60, 0xe6, 0x33, 0xfc, 0x1f, 0xf8, 0x0f, 
	0xf0, 0x07, 0xf0, 0x07, 0xe0, 0x03, 0xc0, 0x01, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'wifi-strength-4', 15x15px
const unsigned char wifistrength4 [] PROGMEM = {
	0x00, 0x00, 0x00, 0x00, 0xf0, 0x07, 0xfc, 0x1f, 0xff, 0x7f, 0xfe, 0x3f, 0xfc, 0x1f, 0xf8, 0x0f, 
	0xf0, 0x07, 0xf0, 0x07, 0xe0, 0x03, 0xc0, 0x01, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00
};


void loop() {
  time(&now);                      // read the current time
  localtime_r(&now, &myTimeInfo);  // update the structure tm with the current time
  updateMyTimeVars();
  if (hr == 1) {
    hourTime = Hour % 24;
    if (hourTime >= 10) {
      hourZero = "";
    } else {
      hourZero = "0";
    };
  } else {
    hourTime = Hour % 12;
    if (hourTime == 0) {
      hourTime = 12;
    };
  };
  minuteTime = Minute;
  if (minuteTime >= 10) {
    minuteZero = "";
  } else {
    minuteZero = "0";
  };
  
  display.clear();
  display.setFont(Roboto_Bold_51);
  display.setTextAlignment(TEXT_ALIGN_CENTER);
  
  if (dateshow == 1) {
  display.drawString(64, 15, hourZero + String(hourTime) + ":" + minuteZero + String(minuteTime));
  display.setFont(Roboto_17);
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  display.drawString(0, 0, String(dayOfWeek[DayIndex])+" "+String(Month)+"/"+String(Day));

  if (WiFi.RSSI() > 25) { // 31 is the value given to a connection that doesnt exist
      display.drawXbm(128-15, 0, 15, 15, wifistrengthalertoutline);
  } else if (WiFi.RSSI() > -65 ) {
    display.drawXbm(128-15, 0, 15, 15, wifistrength4);
  } else if (WiFi.RSSI() > -76) {
  display.drawXbm(128-15, 0, 15, 15, wifistrength3);
  } else {
display.drawXbm(128-15, 0, 15, 15, wifistrength1);
  }
    } else {
      display.drawString(64, 5, hourZero + String(hourTime) + ":" + minuteZero + String(minuteTime));
    }
  
  display.display();
  //if (hourTime == 02 and minuteTime == 01) {
  //  if (Second == 01) {
  //    resetFunc();  //call reset - nightly reboot
  //  }
  //};
  delay(100);
}
